package com.rakuten.android.ads.normalizer

import com.ibm.icu.text.Transliterator
import java.text.Normalizer
import java.util.Locale

object QueryNormalizer {

    /**
     * Normalize a string of argument as follows.
     * <ul>
     * <li>Convert half-width to full-width</li>
     * <li>Convert full-width to half-width</li>
     * <li>Convert upper-case to lower-case</li>
     * <li>Convert multi (>=2) spaces to single space</li>
     * <li>Trim spaces (remove spaces at start and end of phrase)</li>
     * </ul>
     *
     * @param query target keywords
     * @return Normalized a string
     * <br><br>
     * <b>Ex.</b><br>
     * <pre>
     * 　String result = QueryNormalizer.normalize("　ﾅｲｷ Nike　ｷﾞﾌﾄ　ナイキ     シューズ   ");
     * 　System.out.println(result);
     * </pre>
     * &nbsp;&nbsp;-&gt;&nbsp;&nbsp;&quot;ナイキ nike ギフト ナイキ シューズ&quot;
     * <br><br>
     * <ul>
     * <li>&quot;ADIDAS　BOOST&quot;&nbsp;&nbsp;-&gt;&nbsp;&nbsp;&quot;adidas boost&quot;</li>
     * <li>&quot;NIkE AIR&quot;&nbsp;&nbsp;-&gt;&nbsp;&nbsp;&quot;nike air&quot;</li>
     * </ul>
     *
     */
    @JvmStatic
    fun normalize(query: String): String {
        if (query.isBlank()) return ""
        // - Replace non-standard white spaces with standard ones
        // - Convert single byte characters to multi byte ones
        var normalizedQuery: String = Transliterator
            .getInstance("Halfwidth-Fullwidth")
            .transliterate(query)
        normalizedQuery = Normalizer.normalize(normalizedQuery, Normalizer.Form.NFKC)
            .lowercase(Locale.getDefault())

        // - Remove consecutive white spaces
        normalizedQuery = normalizedQuery.replace("\\s{2,}".toRegex(), " ")

        // Trim the string
        return normalizedQuery.trim()
    }
}
