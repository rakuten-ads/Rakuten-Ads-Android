/**
 * Copyright (C) 2022 Rakuten, inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.rakuten.android.ads.runa

/**
 * This class defines the size of AdView.
 *
 * @since 1.0.0
 */
enum class AdSize(val id: Int) {

    /**
     * The ad size that set in DashBoard.
     */
    DEFAULT(0),

    /**
     * The ad is automatically adjusted to the screen width without changing the aspect ratio of the ad.
     */
    ASPECT_FIT(1),

    /**
     * Can be specified to any size(pixel).<br>
     * However, this specify is calculated based on the width.<br>
     * Specifiable range: (DEFAULT < CUSTOM < ASPECT_FIT)
     */
    CUSTOM(2),
    UNSAFE_CUSTOM(3),
    FULL_SCREEN(4);

    /**
     *
     */
    var width: Int = 0
        set(value) {
            if (name == "CUSTOM" || name == "UNSAFE_CUSTOM") field = value
        }

    /**
     *
     */
    var height: Int = 0
        set(value) {
            if (name == "CUSTOM" || name == "UNSAFE_CUSTOM") field = value
        }

    fun get() = this.id

    companion object {
        fun from(id: Int): AdSize =
            when (id) {
                0 -> DEFAULT
                1 -> ASPECT_FIT
                2 -> CUSTOM
                3 -> UNSAFE_CUSTOM
                4 -> FULL_SCREEN
                else -> DEFAULT
            }
    }
}
