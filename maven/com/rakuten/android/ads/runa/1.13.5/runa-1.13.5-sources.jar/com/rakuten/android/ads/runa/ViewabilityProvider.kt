/**
 * Copyright (C) 2022 Rakuten, inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.rakuten.android.ads.runa

import android.view.View
import com.rakuten.android.ads.core.logging.Logger
import com.rakuten.android.ads.runa.internal.presentation.viewmodel.ViewabilityObservable
import com.rakuten.android.ads.runa.internal.presentation.viewmodel.ViewabilityProviderModel

/**
 * @suppress
 */
class ViewabilityProvider private constructor() {

    companion object {

        private val viewabilityObservable: ViewabilityObservable =
            ViewabilityProviderModel.getInstance()

        @JvmStatic
        fun register(
            view: View,
            url: String,
            l: ViewabilityListener? = null,
        ) {
            if (url.isBlank()) {
                Logger.error("url for the Viewability must be not empty.")
                return
            }
            viewabilityObservable.startObserve(view, url, l)
        }

        @JvmStatic
        fun unregister(view: View) {
            viewabilityObservable.stopObserve(view)
        }
    }

    interface ViewabilityListener {

        fun onEstablished()
    }
}
