/**
 * Copyright (C) 2022 Rakuten, inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.rakuten.android.ads.runa

import android.view.View

/**
 * A listener for receiving notifications during the lifecycle of an ad.
 *
 * @since 1.0.0
 */
abstract class AdStateListener {

    /**
     * Called when an ad is received.<br>
     * It is called this method, if it is loaded an advertise successfully.
     */
    open fun onLoadSuccess(view: View? = null) {}

    /**
     * Called when an ad request failed.<br>
     * It is called this method, in case of loaded an advertise failure.<br>
     * And if it failed, AdView will be hidden(View.INVISIBLE) automatically.
     *
     * @param view target view
     * @param errorState Indicates the status when an error occurred in AdRequest.
     */
    open fun onLoadFailure(view: View? = null, errorState: ErrorState) {}

    /**
     * Called when a click is recorded for an ad.<br>
     * It is called this method, if it is clicked an advertise.<br>
     * <br>
     * e.g. You use this method in case of to detect that clicked ad.
     *
     * @param view target view
     * @param errorState Returns when the transition at the time of clicking fails.
     */
    open fun onClick(view: View? = null, errorState: ErrorState?) {}

    /**
     * Called when an ad leaves an application<br>
     * This method is called after `onClick()` when a user click opens browser(transition to ad's destination URL).<br>
     * <br>
     *  e.g. launched browser, launched other app.
     */
    open fun onLeftApplication() {}

    /**
     * Called when return to an application from Ad page.<br>
     * When a user returns to the app after viewing an ad's destination URL, this method is called.
     */
    open fun onAdClosed() {}

    /**
     * Called when WebView in AdView crashed.
     * You should remove AdView from the view hierarchy when this method is called.
     */
    open fun onWebViewCrashed(adView: AdView?) {}


    /**
     * Called when a close message is received from JS SDK.
     * This is typically used for interstitial ads to handle close actions.
     */
    open fun onCloseMessageReceived() {}
}
