/**
 * Copyright (C) 2022 Rakuten, inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.rakuten.android.ads.runa

import android.annotation.TargetApi
import android.content.Context
import android.os.Build
import android.os.Bundle
import android.util.AttributeSet
import androidx.annotation.DrawableRes
import com.rakuten.android.ads.runa.internal.presentation.view.BaseCarouselAdView
import com.rakuten.android.ads.runa.internal.presentation.view.CarouselAdClient
import org.json.JSONObject

/**
 * View object for carousel ads. Ad spot ID or Ad spot Code must be set prior to calling `show()`.<br>
 * <br>
 * -> &nbsp; [Sample Code](https://github.com/rakuten-ads/Rakuten-Ads-Android/blob/master/doc/api/CarouselAdView.md#sample-code)
 *
 * @since 1.6.0
 */
class CarouselAdView : BaseCarouselAdView, CarouselAdClient {

    constructor(context: Context) : super(context)
    constructor(context: Context, attrs: AttributeSet?) : super(context, attrs)
    constructor(context: Context, attrs: AttributeSet?, defStyleAttr: Int) : super(
        context,
        attrs,
        defStyleAttr
    )

    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    constructor(
        context: Context,
        attrs: AttributeSet?,
        defStyleAttr: Int,
        defStyleRes: Int
    ) : super(
        context,
        attrs,
        defStyleAttr,
        defStyleRes
    )

    /**
     * The event callback of CarouselAdView<br>
     * Sets Listener to detect CarouselAdView events.
     */
    override var carouselAdStateListener: CarouselAdStateListener?
        get() = super.carouselAdStateListener
        set(value) {
            super.carouselAdStateListener = value
        }

    /**
     * If set to true, it will be a sticky move like ViewPager<br>
     * Default value is *false*<br>
     *
     * ![Enable PagerSnap Image](https://raw.githubusercontent.com/rakuten-ads/Rakuten-Ads-Android/master/doc/img/carouselads/003.png)
     *
     */
    override var isPagerSnapEnabled: Boolean
        get() = super.isPagerSnapEnabled
        set(value) {
            super.isPagerSnapEnabled = value
        }

    /**
     *  Specifies the size of the ad to display within the CarouselAdView frame.<br>
     *  Default value is *AdSize.DEFAULT* <br>
     *  <br>
     *  - DEFAULT :
     *  ![Default Image](https://raw.githubusercontent.com/rakuten-ads/Rakuten-Ads-Android/master/doc/img/carouselads/001.png)
     *
     *  - ASPECT_FIT :
     *  ![Default Image](https://raw.githubusercontent.com/rakuten-ads/Rakuten-Ads-Android/master/doc/img/carouselads/002.png)
     *
     */
    override var nestedAdsSize: AdSize
        get() = super.nestedAdsSize
        set(value) {
            super.nestedAdsSize = value
        }

    /**
     * If you set CUSTOM to nestedAdsSize, you can change the width of the ads displayed in CarouselAdView to any size.<br>
     * However, if you set a value for this property, set nestedAdsCustomHeight to *LayoutParams.WRAP_CONTENT* (Because it keeps the ratio of the original size.).
     *
     * Default value is *0*
     */
    override var nestedAdsCustomWidth: Int
        get() = super.nestedAdsCustomWidth
        set(value) {
            super.nestedAdsCustomWidth = value
        }

    /**
     * If you set CUSTOM to nestedAdsSize, you can change the height of the ads displayed in CarouselAdView to any size.
     * However, if you set a value for this property, set nestedAdsCustomHeight to *LayoutParams.WRAP_CONTENT* (Because it keeps the ratio of the original size.).
     *
     * Default value is *0*
     */
    override var nestedAdsCustomHeight: Int
        get() = super.nestedAdsCustomHeight
        set(value) {
            super.nestedAdsCustomHeight = value
        }

    /**
     * Overhang width of adjacent ads when `isPagerSnapEnabled` is enabled.
     *
     * Only numbers greater than 0 are valid for this parameter.
     *
     * Default value is *0*
     *
     * ![Description Image](https://raw.githubusercontent.com/rakuten-ads/Rakuten-Ads-Android/master/doc/img/carouselads/006.png)
     */
    override var overhangWidth: Int
        get() = super.overhangWidth
        set(value) {
            super.overhangWidth = value
        }

    /**
     * Ad-to-ad spacing width.
     *
     * Only numbers greater than 0 are valid for this parameter.
     *
     * Default value is *0*
     *
     * ![Description Image](https://raw.githubusercontent.com/rakuten-ads/Rakuten-Ads-Android/master/doc/img/carouselads/005.png)
     */
    override var adsSeparatorWidth: Int
        get() = super.adsSeparatorWidth
        set(value) {
            super.adsSeparatorWidth = value
        }

    /**
     * Sets offset(px) to left of first ad. This property is enabled when more than one ad is displayed.
     *
     * Only numbers greater than 0 are valid for this parameter.
     *
     * Default value is *0*
     *
     * ![Description Image](https://raw.githubusercontent.com/rakuten-ads/Rakuten-Ads-Android/master/doc/img/carouselads/005.png)
     *
     * @since 1.6.3
     */
    override var offsetStartWidth: Int
        get() = super.offsetStartWidth
        set(value) {
            super.offsetStartWidth = value
        }

    /**
     * Sets offset(px) to right of end ad. This property is enabled when more than one ad is displayed.
     *
     * Only numbers greater than 0 are valid for this parameter.
     *
     * Default value is *0*
     *
     * ![Description Image](https://raw.githubusercontent.com/rakuten-ads/Rakuten-Ads-Android/master/doc/img/carouselads/005.png)
     *
     * @since 1.6.3
     */
    override var offsetEndWidth: Int
        get() = super.offsetEndWidth
        set(value) {
            super.offsetEndWidth = value
        }

    /**
     * Enables the display of the indicator.
     *
     * Default value is *false*
     *
     * ![With Indicator Image](https://raw.githubusercontent.com/rakuten-ads/Rakuten-Ads-Android/master/doc/img/carouselads/004.png)
     *
     */
    override var isIndicatorEnabled: Boolean
        get() = super.isIndicatorEnabled
        set(value) {
            super.isIndicatorEnabled = value
        }

    /**
     * This property allows you to change the design of the indicator.<br>
     * Specify the Drawable resource id.
     */
    override var indicatorBackground: Int
        get() = super.indicatorBackground
        set(@DrawableRes value) {
            super.indicatorBackground = value
        }

    /**
     * Add the AdSpot IDs.
     *
     * @param adSpotIds ID issued on the dashboard
     */
    override fun addAdSpotId(vararg adSpotIds: String): CarouselAdView =
        super.addAdSpotId(*adSpotIds) as CarouselAdView

    /**
     * Add an ID with a property for customization.
     *
     * @param adSpotId ID issued on the dashboard
     * @param property For customization
     */
    override fun addAdSpotId(adSpotId: String, property: JSONObject?): CarouselAdView =
        super.addAdSpotId(adSpotId, property) as CarouselAdView

    /**
     * Returns the added AdSpot IDs.
     *
     * @return Array of a pair of AdSpotId and Property.
     */
    override fun getAdSpotIds(): Array<Pair<String, JSONObject?>> = super.getAdSpotIds()

    /**
     * Clear the added AdSpot IDs.
     */
    override fun clearAdSpotIds() {
        super.clearAdSpotIds()
    }

    /**
     * Add the AdSpot code.
     *
     * @param adSpotCode Code issued on the dashboard
     */
    override fun addAdSpotCode(vararg adSpotCode: String): CarouselAdView =
        super.addAdSpotCode(*adSpotCode) as CarouselAdView

    /**
     * Add a code with a property for customization.
     *
     * @param adSpotCode Code issued on the dashboard
     * @param property For customization
     */
    override fun addAdSpotCode(adSpotCode: String, property: JSONObject?): CarouselAdView =
        super.addAdSpotCode(adSpotCode, property) as CarouselAdView

    /**
     * Returns the added AdSpot codes.
     *
     * @return Array of a pair of AdSpotId and Property.
     */
    override fun getAdSpotCodes(): Array<Pair<String, JSONObject?>> = super.getAdSpotCodes()

    /**
     * Clear the added AdSpot codes.
     */
    override fun clearAdSpotCodes() {
        super.clearAdSpotCodes()
    }

    /**
     * Add an AdView instance to display ads.<br>
     * Do not execute the show method of the AdView to be added.
     *
     * @param adViews [AdView]
     */
    override fun add(vararg adViews: AdView): CarouselAdView = super.add(*adViews) as CarouselAdView

    /**
     * Returns the added AdViews with array.
     *
     * @return Array of [AdView]
     */
    override fun getAdViews(): Array<AdView> = super.getAdViews()

    /**
     * Clear the added AdViews.
     */
    override fun clearAdViews() {
        super.clearAdViews()
    }

    /**
     * Specify any key/value required for customization.
     */
    override fun putProperty(key: String, value: Any): CarouselAdView =
        super.putProperty(key, value) as CarouselAdView

    /**
     * Returns the added properties with *Bundle*.
     */
    override fun getProperty(): Bundle = super.getProperty()

    override fun setProperty(value: Bundle) {
        super.setProperty(value)
    }

    /**
     * Returns whether it is loading with Boolean.<br>
     * @return true is still loading, false means stopped or loaded.
     */
    override fun isLoading(): Boolean = super.isLoading()

    /**
     * Performs ads loading.
     */
    override fun show() {
        super.show()
    }
}
