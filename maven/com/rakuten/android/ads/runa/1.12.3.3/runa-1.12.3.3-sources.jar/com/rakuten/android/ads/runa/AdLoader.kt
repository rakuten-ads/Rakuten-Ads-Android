/**
 * Copyright (C) 2022 Rakuten, inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.rakuten.android.ads.runa

import android.content.Context
import android.os.Bundle
import com.rakuten.android.ads.runa.internal.application.RunaLauncher
import com.rakuten.android.ads.runa.internal.di.DataInjector.AdLoaderModelInjector.Companion.inject
import com.rakuten.android.ads.runa.internal.domain.delegate.AdLoaderDelegate

/**
 *  Use AdLoader to display multiple ads with one load, such as displaying carousel ads.<br>
 * AdLoader consists of a Builder pattern, so need to declare the AdLoader$Builder class and add some parameters to load ads.<br>
 * Add AdView to draw with the Builder, and sets AdLoaderStateListener to detect the loading status of AdLoader as needed.<br>
 * Generates AdLoader with `build` method after added parameters to the Builder, AdLoader starts loading ads that uses `execute` method.<br>
 * When loading starts, the loaded AdView will be drawn in sequence. At this time, the drawing order cannot be controlled.<br>
 * Also, when loading ads with AdLoader, you don't need to implement deduplication with RunaAdSession, because this includes deduplication functionality.<br>
 * <br>
 * ->&nbsp;[Sample Code](https://github.com/rakuten-ads/Rakuten-Ads-Android/blob/master/doc/api/AdLoader.md#sample-code)
 *
 * @since 1.3.0
 */
class AdLoader private constructor(private val delegate: AdLoaderDelegate) {

    private val loaderModel = inject(this, delegate)

    /**
     * Returns a List of the added AdViews.
     */
    fun getAdViews(): List<AdView> =
        delegate.getAdLoaderProvider().getBannerAdClients().map { it as AdView }

    /**
     * Execute ads loading.<br>
     * The data of the loaded advertisement will be apply in the added each AdViews.
     */
    fun execute() = loaderModel.load()

    /**
     * Whether AdLoader is loading ads.
     *
     * @return If true, it's loading.
     */
    fun isLoading(): Boolean = loaderModel.isLoading()

    /**
     * Returns a list of loaded and valid AdViews only.
     * This array does not contain AdViews that have loaded invalid data(Unfilled etc).
     * Loads are performed asynchronously, so the return is null until all loads are complete.
     *
     * @return An array of AdViews.
     */
    fun getValidAdViews(): List<AdView>? =
        this.loaderModel.getAvailableBannerAdClients().run {
            if (0 < size) map { it as AdView } else null
        }

    /**
     * The Builder to build an AdLoader.
     */
    class Builder(context: Context) {

        private val adViewList = ArrayList<AdView>()
        private val builder: AdLoaderDelegate.Builder = AdLoaderDelegate.Builder(context.applicationContext)

        init {
            require(RunaLauncher.isLaunched) { "Runa is not initialized. It must be call Runa.init(this) in onCreate() of the class that inherited Application." }
        }

        /**
         * Adds the target AdView.
         *
         * @param adViews AdViews to load ad.
         */
        fun add(vararg adViews: AdView): Builder = apply {
            adViews.map {
                if (it.adSpotId.isBlank() && it.adSpotCode.isBlank()) throw IllegalArgumentException("AdSpotID or AdSpotCode must be set to all AdViews!")
                it.lock()
                this.adViewList.add(it)
            }
        }

        /**
         * Sets a listener to detect the lifecycle of each AdView.
         *
         * @param adLoaderStateListener AdLoaderStateListener
         */
        fun with(adLoaderStateListener: AdLoaderStateListener): Builder = apply {
            this.builder.setAdLoaderStateListener(adLoaderStateListener)
        }

        /**
         * Adds key/value parameter
         */
        fun putProperty(key: String, value: Any): Builder = apply {
            this.builder.putProperty(key, value)
        }

        internal fun setProperty(property: Bundle) = apply {
            this.builder.setProperty(property)
        }

        /**
         * Generates AdLoader
         *
         * @throws IllegalStateException Throws exception if you did not add AdView also not set adSpotId to AdView.
         * @return AdLoader
         *
         */
        @Throws(IllegalStateException::class)
        fun build(): AdLoader =
            if (0 < adViewList.size)
                AdLoader(
                    builder.apply {
                        adViewList.forEach { it.prepare() }
                        setBannerAdClientList(adViewList.toTypedArray())
                    }.build()
                )
            else throw IllegalStateException("Must be add one or more AdViews.")
    }
}
