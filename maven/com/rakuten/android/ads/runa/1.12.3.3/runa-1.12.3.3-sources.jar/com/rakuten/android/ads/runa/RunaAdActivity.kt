package com.rakuten.android.ads.runa

import android.app.Activity
import android.os.Bundle
import com.rakuten.android.ads.runa.internal.presentation.viewmodel.InterstitialAdLoader

class RunaActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        InterstitialAdLoader.onCreateActivity(this)
    }

    override fun onDestroy() {
        InterstitialAdLoader.onDestroyActivity()
        super.onDestroy()
    }

    companion object {
        internal const val KEY = "com.rakuten.android.ads.runa.RunaActivity"
    }
}
