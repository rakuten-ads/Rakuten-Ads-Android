/**
 * Copyright (C) 2022 Rakuten, inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.rakuten.android.ads.runa

/**
 * A listener for receiving notifications during the lifecycle of an ad.
 *
 * @since 1.3.0
 */
abstract class AdLoaderStateListener : AdStateListener() {

    /**
     * Called when AdViews added to AdLoader have been all loaded.
     */
    open fun onAllLoadsFinished(adLoader: AdLoader, loadedAdViews: List<AdView>) { }
}
