/**
 * Copyright (C) 2022 Rakuten, inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.rakuten.android.ads.runa

import android.app.Activity
import android.os.Bundle
import android.view.View
import com.rakuten.android.ads.core.util.isUIThread
import java.lang.ref.WeakReference

/**
 * Uses this class to avoid duplication of display ad content, in case of sets multiple AdView on same Screen.<br>
 * <br>
 * ->&nbsp;[Sample Code](https://github.com/rakuten-ads/Rakuten-Ads-Android/blob/master/doc/api/RunaAdSession.md#implementation-sample)
 *
 * @since 1.2.0
 */
class RunaAdSession : AdSession {

    private var instanceState: Bundle = Bundle()
    private var adViewList = ArrayList<WeakReference<AdView>>()
    private var adViewIdList = ArrayList<Int>()

    /**
     * Sets multiple AdView to this method to avoid duplication of ads display in those AdViews.<br>
     * Also when set multiple AdView in this method, allow an interval to execute those `AdVie$show` method, because browse to the ads loaded of the previously bound AdView.
     *
     * @param adView [AdView]
     */
    override fun bind(vararg adView: AdView) {
        check(isUIThread()) { "This bind() must be executed from UI thread." }
        adView.map {
            it.saveInstanceState(instanceState)
            if (it.id == View.NO_ID) adViewList.add(WeakReference(it))
            else adViewIdList.add(it.id)
        }
    }

    /**
     * Cancel all AdView sessions bound on that Activity.
     *
     * @param activity An [Activity] where the AdView is placed.
     */
    override fun unbindAll(activity: Activity) {
        check(isUIThread()) { "This unbindAll() must be executed from UI thread." }
        try {
            adViewIdList.forEach {
                activity.findViewById<AdView>(it)?.let {
                    it.resetInstanceState()
                }
            }
            adViewList.forEach {
                try {
                    it.get()?.let {
                        it.resetInstanceState()
                    }
                } catch (e: NullPointerException) {}
            }
        } finally {
            instanceState = Bundle()
            adViewList = ArrayList()
            adViewIdList = ArrayList()
        }
    }
}
