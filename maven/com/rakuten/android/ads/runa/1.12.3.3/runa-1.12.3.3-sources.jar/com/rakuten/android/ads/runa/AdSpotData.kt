package com.rakuten.android.ads.runa

import android.os.Bundle
import androidx.annotation.ColorInt
import androidx.annotation.DrawableRes
import com.rakuten.android.ads.runa.key.AdSpotBranch

/**
 * @param adSpotId AdSpotID
 * @param adSpotCode AdSpotCode
 * @param properties Properties
 */
open class AdSpotData(
    open val adSpotId: String,
    open val adSpotCode: String = "",
    open val adSpotBranchId: Int = -1,
    open val adSize: AdSize = AdSize.DEFAULT,
    open val properties: Bundle? = null
) : java.io.Serializable

data class InterstitialAdSpotData(
    override val adSpotId: String,
    override val adSpotCode: String = "",
    override val adSpotBranchId: Int = -1,
    override val adSize: AdSize = AdSize.ASPECT_FIT,
    override val properties: Bundle? = null,
    @ColorInt val backgroundColor: Int = 0,
    @DrawableRes val closeButtonDrawable: Int = 0
) : AdSpotData(
    adSpotId = adSpotId,
    adSpotCode = adSpotCode,
    adSize = adSize,
    properties = properties
) {

    fun toBundle(): Bundle = Bundle().apply {
        putString(KEY_ADSPOT_ID, adSpotId)
        putString(KEY_ADSPOT_CODE, adSpotCode)
        putInt(KEY_ADSIZE, adSize.id)
        if (1 <= adSpotBranchId) putInt(KEY_ADSPOT_BRANCH_ID, adSpotBranchId)
        if (adSize == AdSize.CUSTOM) {
            putInt(KEY_ADSIZE_WIDTH, adSize.width)
            putInt(KEY_ADSIZE_HEIGHT, adSize.height)
        }
        putBundle(KEY_PROPERTIES, properties)
        putInt(KEY_BACKGROUND_COLOR, backgroundColor ?: 0)
        putInt(KEY_CLOSE_BTN_RES, closeButtonDrawable ?: 0)
    }

    companion object {
        const val KEY_ADSPOT_ID = "ad_spot_id"
        const val KEY_ADSPOT_CODE = "ad_spot_code"
        const val KEY_ADSPOT_BRANCH_ID = "ad_spot_branch_id"
        const val KEY_ADSIZE = "ad_size"
        const val KEY_ADSIZE_WIDTH = "ad_size_width"
        const val KEY_ADSIZE_HEIGHT = "ad_size_height"
        const val KEY_PROPERTIES = "ad_properties"
        const val KEY_BACKGROUND_COLOR = "ad_background_color"
        const val KEY_CLOSE_BTN_RES = "ad_close_btn_res"
    }
}
