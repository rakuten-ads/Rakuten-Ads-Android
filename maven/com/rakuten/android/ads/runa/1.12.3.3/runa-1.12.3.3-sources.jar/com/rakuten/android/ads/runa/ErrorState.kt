/**
 * Copyright (C) 2022 Rakuten, inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.rakuten.android.ads.runa

/**
 * Indicates the status when an error occurred in AdRequest.
 *
 * @since 1.0.0
 */
enum class ErrorState {

    /**
     * The ad request was successful, but no ad was returned due to lack of ad inventory.
     */
    UNFILLED,

    /**
     * The ad request was invalid. For instance, the ad spot ID was incorrect.
     */
    FATAL_ERROR,

    /**
     * The ad request was unsuccessful due to network connectivity.
     */
    NETWORK_ERROR,

    /**
     * Something happened internally.
     * For instance, an invalid response was received from the ad server.
     */
    INTERNAL_ERROR,

    /**
     * The ad request timed out.
     */
    TIME_OUT,

    /**
     * Transition when clicked failed.
     */
    TRANSITION_ERROR;
}
