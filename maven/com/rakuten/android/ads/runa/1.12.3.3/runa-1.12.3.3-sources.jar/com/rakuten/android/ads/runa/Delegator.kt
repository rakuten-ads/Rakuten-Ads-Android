package com.rakuten.android.ads.runa

import com.rakuten.android.ads.runa.internal.presentation.view.Delegation

enum class Delegator : Delegation {
    ClickDelegation
}
