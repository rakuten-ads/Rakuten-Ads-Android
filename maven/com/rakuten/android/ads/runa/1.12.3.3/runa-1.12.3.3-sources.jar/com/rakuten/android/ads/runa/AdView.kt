/**
 * Copyright (C) 2022 Rakuten, inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.rakuten.android.ads.runa

import android.annotation.TargetApi
import android.content.Context
import android.os.Build
import android.os.Bundle
import android.util.AttributeSet
import android.util.Size
import android.view.MotionEvent
import com.rakuten.android.ads.runa.internal.presentation.view.BannerAdClient
import com.rakuten.android.ads.runa.internal.presentation.view.BaseAdView
import com.rakuten.android.ads.runa.key.AdSpotBranch

/**
 * The View to display Banner ads.<br>
 * An ad spot ID must be set prior to calling `show()`.<br>
 * <br>
 * -> &nbsp; [Sample Code](https://github.com/rakuten-ads/Rakuten-Ads-Android/blob/master/doc/api/AdView.md#sample-code)
 *
 * @since 1.0.0
 */
class AdView : BaseAdView, BannerAdClient {

    constructor(context: Context) : super(context)
    constructor(context: Context, attrs: AttributeSet?) : super(context, attrs)
    constructor(context: Context, attrs: AttributeSet?, defStyleAttr: Int) : super(context, attrs, defStyleAttr)
    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    constructor(context: Context, attrs: AttributeSet?, defStyleAttr: Int, defStyleRes: Int) : super(
        context,
        attrs,
        defStyleAttr,
        defStyleRes
    )

    /**
     * Ad spot ID
     */
    override var adSpotId: String
        get() = super.adSpotId
        set(value) {
            super.adSpotId = value
        }

    /**
     * Ad spot Code
     *
     * @since 1.6.0
     */
    override var adSpotCode: String
        get() = super.adSpotCode
        set(value) {
            super.adSpotCode = value
        }

    /**
     * Ad spot branch ID
     *
     * @since 1.8.0
     */
    override var adSpotBranchId: AdSpotBranch
        get() = super.adSpotBranchId
        set(value) {
            super.adSpotBranchId = value
        }

    /**
     * The event callback of AdView
     */
    override var adStateListener: AdStateListener?
        get() = super.adStateListener
        set(value) {
            super.adStateListener = value
        }

    /**
     *
     */
    override var motionInformer: ((MotionEvent) -> Unit)?
        get() = super.motionInformer
        set(value) {
            super.motionInformer = value
        }

    /**
     * An option for specifying AdView size.<br>
     * Default value is AdSize.DEFAULT
     */
    override var adViewSize: AdSize
        get() = super.adViewSize
        set(value) {
            super.adViewSize = value
        }

    /**
     * The property for setting options.
     */
    override var property: Bundle
        get() = super.property
        set(value) {
            super.property = value
        }

    /**
     * Returns width and height if adViewSize is CUSTOM.
     */
    override fun getCustomSize(): Size = super.getCustomSize()

    /**
     * Specify any key/value required for customization.
     */
    override fun putProperty(key: String, value: Any): BaseAdView = super.putProperty(key, value)

    /**
     * Returns whether it is loading with Boolean.<br>
     * @return true is still loading, false means stopped or loaded.
     */
    override fun isLoading(): Boolean = super.isLoading()

    /**
     * Returns whether it is available with Boolean.<br>
     * @return true is available, false means unavailable.
     */
    override fun isAvailable(): Boolean = super.isAvailable()

    /**
     * Returns session id.
     *
     * @since 1.2.0
     */
    override fun getSessionId(): String = super.getSessionId()

    /**
     * Performs ad loading.
     */
    override fun show() = super.show()
}
