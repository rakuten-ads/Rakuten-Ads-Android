package com.rakuten.android.ads.runa

import android.app.Activity
import android.content.Context
import com.rakuten.android.ads.runa.internal.domain.delegate.IInterstitialAd
import com.rakuten.android.ads.runa.internal.domain.delegate.InterstitialAdDelegate
import com.rakuten.android.ads.runa.internal.presentation.viewmodel.InterstitialAdLoader

abstract class InterstitialAd {

    abstract var interstitialAdListener: InterstitialAdListener?

    abstract fun show(activity: Activity)

    companion object {

        @JvmStatic
        fun load(
            context: Context,
            adSpotData: InterstitialAdSpotData,
            listener: InterstitialAdLoadListener
        ) {
            require(adSpotData.adSpotId.isNotBlank() || adSpotData.adSpotCode.isNotBlank()) { "AdSpotId or AdSpotCode must be not empty!!" }
            val delegate: IInterstitialAd =
                InterstitialAdDelegate.Builder(context.applicationContext).apply {
                    setAdSpotData(adSpotData)
                    setInterstitialAdLoadListener(listener)
                }.build()
            InterstitialAdLoader(delegate).load()
        }
    }
}

abstract class InterstitialAdLoadListener {

    /**
     * It is called this method, if it is loaded an interstitial ad successfully.
     */
    open fun onLoadSuccess(interstitialAd: InterstitialAd) {}

    /**
     * Called when an interstitial ad request failed.<br>
     * It is called this method, in case of loaded an advertise failure.<br>
     *
     * @param errorState Indicates the status when an error occurred in AdRequest.
     */
    open fun onLoadFailure(errorState: ErrorState) {}
}

abstract class InterstitialAdListener : AdStateListener() {

    open fun onDismiss() {}
}
