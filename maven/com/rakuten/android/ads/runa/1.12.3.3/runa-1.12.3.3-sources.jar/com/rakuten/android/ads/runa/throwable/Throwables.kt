package com.rakuten.android.ads.runa.throwable

import java.lang.UnsupportedOperationException

class RunaUnsupportedOperationException : UnsupportedOperationException {

    constructor() : super()

    constructor(message: String) : super(message)

    constructor(message: String, cause: Throwable) : super(message, cause)
}
