/**
 * Copyright (C) 2022 Rakuten, inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.rakuten.android.ads.runa

import android.app.Application
import com.rakuten.android.ads.runa.internal.application.RunaConfig
import com.rakuten.android.ads.runa.internal.application.RunaLauncher

/**
 * The configuration of Ad SDK.<br>
 * <br>
 * -> &nbsp; [Sample Code](https://github.com/rakuten-ads/Rakuten-Ads-Android/blob/master/doc/api/Runa.md#sample-code)
 *
 * @since 1.4.0
 */
object Runa {

    /**
     * **[Required]**<br>
     * Activate the Runa SDK<br>
     * This function must be call in onCreate() of the class that inherited Application.
     */
    @JvmStatic
    fun init(application: Application): Runa = apply { RunaLauncher.launch(application) }

    /**
     * Enables log output of Runa SDK.
     */
    @JvmStatic
    var debug: Boolean = false
        get() = field
        set(value) {
            field = value
            com.rakuten.android.ads.runa.common.ClientState.setDebug(value)
            com.rakuten.android.ads.core.logging.Logger.verboseMode(value)
            com.rakuten.android.ads.core.logging.DebugToast.verboseMode(value)
        }

    object Build {

        /**
         * Runa SDK's version
         */
        const val SDK_VERSION = BuildConfig.SDK_VERSION

        /**
         * Runa SDK's type
         */
        @JvmStatic
        val TYPE: Int = RunaConfig.env.type

        /**
         * The version of the submodule supported by Runa SDK.
         */
        object SubModules {

            /**
             * Name of SDK core
             */
            const val MODULE_SDK_CORE_NAME = com.rakuten.android.ads.core.Build.SDK_NAME

            /**
             * The version of SDK core
             */
            const val MODULE_SDK_CORE_VERSION = com.rakuten.android.ads.core.Build.SDK_VERSION

            /**
             * Name of Common module
             */
            const val MODULE_COMMON_NAME = com.rakuten.android.ads.runa.common.Build.SDK_NAME

            /**
             * The version of Common module
             */
            const val MODULE_COMMON_VERSION = com.rakuten.android.ads.runa.common.Build.SDK_VERSION

            /**
             * Name of Tracker module
             */
            const val MODULE_TRACKER_NAME = com.rakuten.android.ads.runa.track.Build.SDK_NAME

            /**
             * The version of Tracker module
             */
            const val MODULE_TRACKER_VERSION = com.rakuten.android.ads.runa.track.Build.SDK_VERSION

            /**
             * Name of OM module
             */
            const val MODULE_OM_NAME = com.rakuten.android.ads.runa.om.Build.SDK_NAME

            /**
             * The version of OpenMeasurement SDK module
             */
            const val MODULE_OM_VERSION = com.rakuten.android.ads.runa.om.Build.SDK_VERSION
        }
    }
}
