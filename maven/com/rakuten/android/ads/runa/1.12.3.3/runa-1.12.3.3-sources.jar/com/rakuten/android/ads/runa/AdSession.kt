package com.rakuten.android.ads.runa

import android.app.Activity

/**
 * @suppress
 *
 * @since 1.2.0
 */
interface AdSession {

    fun bind(vararg adView: AdView)

    fun unbindAll(activity: Activity)
}
