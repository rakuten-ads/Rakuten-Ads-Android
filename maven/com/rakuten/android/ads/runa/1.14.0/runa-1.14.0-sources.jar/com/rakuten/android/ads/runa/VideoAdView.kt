package com.rakuten.android.ads.runa

import android.app.Activity
import android.content.Context
import android.util.AttributeSet
import android.view.ViewGroup
import com.rakuten.android.ads.core.api.service.HttpApiRequest
import com.rakuten.android.ads.core.logging.Logger
import com.rakuten.android.ads.core.util.convertString
import com.rakuten.android.ads.runa.internal.application.RunaConfig
import com.rakuten.android.ads.runa.internal.application.RunaLauncher
import com.rakuten.android.ads.runa.internal.domain.usecase.adaction.VideoObserverUseCaseImpl
import com.rakuten.android.ads.runa.internal.domain.usecase.adaction.TwoSecObserverUseCaseImpl
import com.rakuten.android.ads.runa.internal.domain.usecase.adaction.VideoViewabilityUseCaseImpl
import com.rakuten.android.ads.runa.internal.domain.usecase.adaction.ViewabilityUseCase
import com.rakuten.android.ads.runa.internal.domain.usecase.adaction.ViewabilityUseCaseImpl
import com.rakuten.android.ads.runa.internal.presentation.view.RunaAdViewGroup
import com.rakuten.android.ads.runa.internal.presentation.view.VideoWebView
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import java.io.InputStream

class VideoAdView : RunaAdViewGroup {
    var vastXml: String? = null
    var impUrl: String? = null
    var inviewUrl: String? = null
    var adStateListener: VideoAdStateListener? = null
    private val viewabilityObserver: ViewabilityUseCase<Boolean> = VideoViewabilityUseCaseImpl(this, VideoObserverUseCaseImpl)
    private val vImpressionObserver = ViewabilityUseCaseImpl(this, TwoSecObserverUseCaseImpl)

    constructor(context: Context) : this(context, null)
    constructor(context: Context, attrs: AttributeSet?) : this(context, attrs, 0)
    constructor(context: Context, attrs: AttributeSet?, defStyleAttr: Int) : super(
        context, attrs, defStyleAttr
    ) {
        check(RunaLauncher.Companion.isLaunched) { "Runa is not initialized. It must be call Runa.init(this) in onCreate() of the class that inherited Application." }
        require(context is Activity) { "Context of CarouselAdView constructor argument must be 'ActivityContext'." }
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec)
        val width = measuredWidth
        val height = width * 9 / 16
        setMeasuredDimension(width, height)
        getChildAtInternal(0)?.measure(
            MeasureSpec.makeMeasureSpec(width, MeasureSpec.EXACTLY),
            MeasureSpec.makeMeasureSpec(height, MeasureSpec.EXACTLY)
        )
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        getChildAtInternal(0)?.layout(0, 0, r - l, b - t)
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        (getChildAtInternal(0) as? VideoWebView)?.stopVideo()
        vImpressionObserver.stopObserve()
    }

    fun show() {
        val nonNullVastXml = requireNotNull(vastXml) { "VAST xml is required." }
        val nonNullImpUrl = requireNotNull(impUrl) { "Impression URL is required." }
        val nonNullInviewUrl = requireNotNull(inviewUrl) { "Viewable Impression URL is required." }
        val webView = VideoWebView(context, viewabilityObserver, adStateListener, nonNullImpUrl, nonNullInviewUrl, vImpressionObserver)
        addViewInternal(
            webView,
            0,
            ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        )
        val vastScriptTag = createScriptTagWithVast(nonNullVastXml)
        CoroutineScope(Dispatchers.Main).launch {
            val htmlTemplate = try {
                fetchHtmlTemplate()
            } catch (e: Exception) {
                adStateListener?.onLoadFailure(this@VideoAdView, ErrorState.INTERNAL_ERROR)
                return@launch
            }
            val combinedHtml = "$vastScriptTag\n$htmlTemplate"
            webView.loadData(combinedHtml, "text/html", "utf-8")
        }
    }

    private fun createScriptTagWithVast(vastXmlStr: String): String = "<script type='text/javascript'>window.vast=`${vastXmlStr}`</script>"

    private suspend fun fetchHtmlTemplate(): String? = suspendCancellableCoroutine { continuation ->
        val fetcher = HtmlTemplateFetcher()
        fetcher.enqueue(
            onSuccess = { response ->
                continuation.resumeWith(Result.success(response.body?.convertString()))
            },
            onError = { _, _ ->
                continuation.resumeWith(Result.success(null))
            },
            isPostUIThread = false
        )
    }

    abstract class VideoAdStateListener : AdStateListener() {
        open fun onVideoError(adView: VideoAdView?, err: Error) {}
    }

    private class HtmlTemplateFetcher: HttpApiRequest<String>() {
        override fun getRequestUrl(): String = "${RunaConfig.CDN_SERVER_URL}/js/mobile-sdk-video-player.html"

        override fun onSuccess(content: InputStream?): String? =
            content?.bufferedReader()?.use { it.readText() }

    }
}
